import java.util.List;

import org.codehaus.jackson.map.ObjectMapper;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

@Test
public class API_tests {
	
	@BeforeSuite(alwaysRun = true)
	public void configure() {

		RestAssured.baseURI="https://reqres.in/api/users";
		
	}
	@Test
	void getListUsers()
	{
		
		RequestSpecification httpRequest=RestAssured.given();
		
		
		
		JSONObject requestParams=new JSONObject();
		
		httpRequest.header("Content-type", "application/json");
		httpRequest.body(requestParams.toJSONString());
		Response response=httpRequest.post();
		
		int statusCode=response.getStatusCode();
		System.out.println("status code is "+statusCode);
		Assert.assertEquals(statusCode, 201);
		
		
		ResponseBody body=response.getBody();
		JSONUsersObject responseBody=body.as(JSONUsersObject.class);
		
		Assert.assertEquals(2, JSONUsersObject.page);
		Assert.assertEquals(3, JSONUsersObject.per_page);
		Assert.assertEquals(12, JSONUsersObject.total);
		Assert.assertEquals(4, JSONUsersObject.total_pages);
		
		JsonPath jsonPathEvaluator=response.jsonPath();
		
		List<DataArray> data=jsonPathEvaluator.getList("list", DataArray.class);
		
		for(DataArray info : data);
		{
			System.out.println("DataArray: " + DataArray.id);
		}
		
	}
	@Test
	void registration() {
		
		RequestSpecification httpRequest=RestAssured.given();
		JSONObject requestParams=new JSONObject();
		
		requestParams.put("name", "morpheus");
		requestParams.put("job", "leader");
		
		httpRequest.header("Content-type", "application/json");
		httpRequest.body(requestParams.toJSONString());
		Response response=httpRequest.post();
		
		int statusCode=response.getStatusCode();
		System.out.println("status code is "+statusCode);
		Assert.assertEquals(statusCode, 201);
		
		//ResponseBody body=response.getBody();
		//JSONDataObject responseBody=body.as(JSONDataObject.class);
		
		
		
		
		//Response response=httpRequest.request(Method.POST);
		
		//String responseBody=response.getBody().asString();
		//System.out.println("Response Body is:" +responseBody);
		
		//int statusCode=response.getStatusCode();
		//System.out.println("status code is "+statusCode);
		//Assert.assertEquals(statusCode, 201);
		
		//String name=response.jsonPath().get("name");
		//Assert.assertEquals(name, "morpheus");
		
		//String job=response.jsonPath().get("job");
		//Assert.assertEquals(job, "leader");
			
	}
	@Test
	void putRequest() {
		
		RequestSpecification httpRequest=RestAssured.given();
		JSONObject requestParams=new JSONObject();
		
		requestParams.put("name", "morpheus");
		requestParams.put("job", "zion resident");
		
		httpRequest.header("Content-type", "application/json");
		httpRequest.body(requestParams.toJSONString());
		
		Response response=httpRequest.request(Method.PUT, "/2");
		
		String responseBody=response.getBody().asString();
		System.out.println("Response Body is:" +responseBody);
		
		int statusCode=response.getStatusCode();
		System.out.println("status code is "+statusCode);
		Assert.assertEquals(statusCode, 200);
		
		String name=response.jsonPath().get("name");
		Assert.assertEquals(name, "morpheus");
		
		String job=response.jsonPath().get("job");
		Assert.assertEquals(job, "zion resident");
}
	@Test
	void patchRequest() {
		
		RequestSpecification httpRequest=RestAssured.given();
		JSONObject requestParams=new JSONObject();
		
		requestParams.put("name", "morpheus");
		requestParams.put("job", "zion resident");
		
		httpRequest.header("Content-type", "application/json");
		httpRequest.body(requestParams.toJSONString());
		
		Response response=httpRequest.request(Method.PATCH, "/2");
		
		String responseBody=response.getBody().asString();
		System.out.println("Response Body is:" +responseBody);
		
		int statusCode=response.getStatusCode();
		System.out.println("status code is "+statusCode);
		Assert.assertEquals(statusCode, 200);
		
		String name=response.jsonPath().get("name");
		Assert.assertEquals(name, "morpheus");
		
		String job=response.jsonPath().get("job");
		Assert.assertEquals(job, "zion resident");
	
		}
	@Test
	void deleteRequest() {
		
		RequestSpecification httpRequest=RestAssured.given();
		JSONObject requestParams=new JSONObject();
		
		httpRequest.header("Content-type", "application/json");
		httpRequest.body(requestParams.toJSONString());
		
		Response response=httpRequest.request(Method.DELETE, "/2");
		
		String responseBody=response.getBody().asString();
		System.out.println("Response Body is:" +responseBody);
		
		int statusCode=response.getStatusCode();
		System.out.println("status code is "+statusCode);
		Assert.assertEquals(statusCode, 204);
	}
	
}
