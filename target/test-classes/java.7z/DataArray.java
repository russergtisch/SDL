import java.util.List;

public class DataArray {

	public List<DataArray> data;
	public static int id;
	public static String email;
	public static String first_name;
	public static String last_name;
	public static String avatar;
	
}
