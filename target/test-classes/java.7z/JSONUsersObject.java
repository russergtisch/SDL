
public class JSONUsersObject {
	
	public static int page;
	public static int per_page;
	public static int total;
	public static int total_pages;
	public static int getPage() {
		return page;
	}
	public static void setPage(int page) {
		JSONUsersObject.page = page;
	}
	public static int getPer_page() {
		return per_page;
	}
	public static void setPer_page(int per_page) {
		JSONUsersObject.per_page = per_page;
	}
	public static int getTotal() {
		return total;
	}
	public static void setTotal(int total) {
		JSONUsersObject.total = total;
	}
	public static int getTotal_pages() {
		return total_pages;
	}
	public static void setTotal_pages(int total_pages) {
		JSONUsersObject.total_pages = total_pages;
	}
	
}